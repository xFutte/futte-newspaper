export interface ISentence {
	date: string;
	jailed_player: string;
	jailed_time: string;
}

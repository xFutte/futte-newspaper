export interface IReporterLevels {
	grade: number;
	canPublish: boolean;
	canEdit: boolean;
	canDelete: boolean;
}

import { writable } from "svelte/store";

export const visibility = writable(false);

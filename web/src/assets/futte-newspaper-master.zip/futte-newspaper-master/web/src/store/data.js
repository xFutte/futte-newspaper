window.addEventListener('message', (event) => {
	console.log(event.data)
});
